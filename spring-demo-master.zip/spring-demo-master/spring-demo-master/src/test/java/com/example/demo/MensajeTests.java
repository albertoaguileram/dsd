package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.model.Mensaje;
import com.example.demo.model.MensajeRepository;
import com.example.demo.model.MensajeService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MensajeTests {

	private static final String mensajevar_TEST = "me interesa esa petición";
	private static final String mensajevar_TEST2 = "hola,buenas";

	@MockBean
	MensajeRepository mensajeRepository;

	@Autowired
	public MensajeService mensajeService;

	@Test
	public void contextLoads() {
		assertNotNull(mensajeService);
	}

	@Test
	public void testGetOne() {
		// definimos comportamiento del mock
		Mensaje dummyMensaje = new Mensaje();
		dummyMensaje.setMensajevar(mensajevar_TEST);

		Mensaje dummyMensaje2 = new Mensaje();
		dummyMensaje2.setMensajevar(mensajevar_TEST2);
		when(mensajeRepository.getOne(mensajevar_TEST)).thenReturn(dummyMensaje);
		when(mensajeRepository.getOne(mensajevar_TEST2)).thenReturn(dummyMensaje2);

		Mensaje resultMensaje = mensajeService.getByMensaje(mensajevar_TEST);
		verify(mensajeRepository, times(1)).getOne(mensajevar_TEST);
		assertEquals(dummyMensaje, resultMensaje);
		
		Mensaje resultMensaje2=mensajeService.getByMensaje(mensajevar_TEST2);
		assertEquals(dummyMensaje2,resultMensaje2);
	
	}
	@Test
	public void testDelete() {
		mensajeService.delete(mensajevar_TEST);
		verify(mensajeRepository,times(1)).deleteById(mensajevar_TEST);
	
	}
	
	

}
