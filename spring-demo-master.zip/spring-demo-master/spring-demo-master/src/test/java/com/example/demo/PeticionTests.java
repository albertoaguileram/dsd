package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.model.Peticion;
import com.example.demo.model.PeticionRepository;
import com.example.demo.model.PeticionService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PeticionTests {

	public static final long codPeticion_TEST = 5555;
	public static final long codPeticion_TEST2 = 4444;
	
	
	@MockBean
	PeticionRepository peticionRepository;

	@Autowired
	public PeticionService peticionService;

	@Test
	public void contextLoads() {
		assertNotNull(peticionService);
	}
	// Comprueba que obtiene las peticiones definidas
	@Test
	public void testGetOne() {
		// definimos comportamiento del mock
	     Peticion dummyPeticion= new Peticion();
	     dummyPeticion.setCodPeticion(codPeticion_TEST);
	     dummyPeticion.setTitulo("Mudanza");
	     dummyPeticion.setDescripcion("Necesito un ayudante en mi mudanza");
	     dummyPeticion.setDuracion(30);
	     dummyPeticion.setPrioridad(2) ;
	     
	     
	     Peticion dummyPeticion2= new Peticion();
	     dummyPeticion2.setCodPeticion(codPeticion_TEST2);
	     dummyPeticion2.setTitulo("Soporte técnico");
	     dummyPeticion2.setDescripcion("Persona que sepa de tecnología");
	     dummyPeticion2.setDuracion(30);
	     dummyPeticion2.setPrioridad(3);
	     
	     when(peticionRepository.getOne(codPeticion_TEST2)).thenReturn(dummyPeticion2);
	     when(peticionRepository.getOne(codPeticion_TEST)).thenReturn(dummyPeticion);
	    
		// definimos el test
	    Peticion resultPeticion=peticionService.getByCodPeticion(codPeticion_TEST);
		
		verify(peticionRepository,times(1)).getOne(codPeticion_TEST);
		assertEquals(dummyPeticion, resultPeticion);
		
		Peticion resultPeticion2 = peticionService.getByCodPeticion(codPeticion_TEST2);
		assertEquals(dummyPeticion2, resultPeticion2);

		
		
	}
	
	// Comprueba que la peticion se actualiza correctamente
		@Test
		public void testUpdate() { //Arreglar
			
			Peticion resultPeticion = peticionService.getByCodPeticion(codPeticion_TEST);
			resultPeticion.setTitulo("Compromiso");
			peticionService.update(resultPeticion);
			
			Peticion resultPeticion2 = peticionService.getByCodPeticion(codPeticion_TEST);
			assertEquals(resultPeticion2,resultPeticion);
				
		}
		
		// Comprueba que la peticion se elimina, con la llamada al metodo de libroRepository
		@Test
		public void testDelete() {
			peticionService.delete(codPeticion_TEST);
			verify(peticionRepository,times(1)).deleteById(codPeticion_TEST);
		
			
		}

}
