package com.example.demo;

import static org.junit.Assert.assertEquals;



import org.junit.BeforeClass;
import org.junit.Test;

import com.example.demo.model.Registro;

public class RegistroJUnit {

	public static Registro r;
	/*@GeneratedValue(strategy = GenerationType.AUTO)
	public static long id;
	*/
	public static String firstName="Pepe";

	public static String lastName="Moreno";

	public static String email="pepe123@mail.com";

	public static String password="policia1";
	
	@BeforeClass
	public static void create_registro() {
		r=new Registro();
		//r.setId(id);
		r.setEmail(email);
		r.setFirstName(firstName);
		r.setLastName(lastName);
		r.setPassword(password);
		
	}
	
	@Test
	public void registro() {
		//assertEquals("Comprobando id",id,r.getId()); 
        assertEquals("Comprobando email",email,r.getEmail());
        assertEquals("Comprobando nombre",firstName,r.getFirstName());
        assertEquals("Comprobando primer apellido",lastName,r.getLastName());
        assertEquals("Comprobando contraseña",password,r.getPassword());
        
		
	}
	
}
