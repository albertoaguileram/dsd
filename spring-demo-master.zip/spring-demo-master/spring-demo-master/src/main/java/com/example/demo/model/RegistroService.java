package com.example.demo.model;

import java.util.Collection;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class RegistroService implements UserDetailsService{

	private final RegistroRepository repository;

	
	@Autowired
	public RegistroService(RegistroRepository registroRepository) {
		this.repository = registroRepository;
	}

	public List<Registro> getAll() {
		return repository.findAll();
	}



	public Registro getById(long id) {
		return repository.getOne(id);
	}

	public void add(Registro reg) {
		repository.saveAndFlush(reg);
	}


	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Registro reg = repository.findByEmail(username);
		if (reg == null) {
			throw new UsernameNotFoundException("Could not find user " + username);
		}
		return new CustomUserDetails(reg);
	}

	private final static class CustomUserDetails extends Registro implements UserDetails {

		/**
		 * 
		 */
		private static final long serialVersionUID = -5708084648279451366L;

		private CustomUserDetails(Registro reg) {
			super(reg);
		}


		@Override
		public Collection<? extends GrantedAuthority> getAuthorities() {
			return AuthorityUtils.createAuthorityList("ROLE_USER");
		}

		@Override
		public String getUsername() {
			return getEmail();
		}

	
		@Override
		public boolean isAccountNonExpired() {
			return true;
		}

		@Override
		public boolean isAccountNonLocked() {
			return true;
		}

		@Override
		public boolean isCredentialsNonExpired() {
			return true;
		}

		@Override
		public boolean isEnabled() {
			return true;
		}
	}

}
