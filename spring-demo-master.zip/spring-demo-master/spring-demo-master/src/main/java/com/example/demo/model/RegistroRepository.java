package com.example.demo.model;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistroRepository  extends JpaRepository<Registro,Long>{
	 Registro findByEmail(String email);
}
