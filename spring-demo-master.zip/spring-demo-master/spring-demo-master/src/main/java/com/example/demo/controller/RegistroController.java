package com.example.demo.controller;

import javax.validation.Valid;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Registro;
import com.example.demo.model.RegistroService;

@Controller
public class RegistroController {
	@Autowired
	RegistroService service;

	/*@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	*/
	@GetMapping("/login")
	public String loginView() {
		
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
	
		if (!(auth instanceof AnonymousAuthenticationToken)) {
		    return "index";
		}
		return "login";
	}
	
	@GetMapping("/register")
	public String listView(Model model) {
	model.addAttribute("register",service.getAll());
		return "login";
	}

	@GetMapping("/register/add")
	public String addRegisterView(Registro reg, Model model) {
		
		model.addAttribute("registro", reg);
		return "addRegister";
	}

	@PostMapping("/register")
	public String save(@Valid Registro reg, BindingResult result, Model model) {
		
		//String encodedPassword = bCryptPasswordEncoder.encode(reg.getPassword());
		//reg.setPassword(encodedPassword);


		try {
			service.add(reg);
			model.addAttribute("create", true);
		} catch (Exception er) {
			model.addAttribute("create", false);
		}
		return listView(model);
	}

}
