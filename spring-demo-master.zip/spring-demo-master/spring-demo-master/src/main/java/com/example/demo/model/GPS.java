package com.example.demo.model;

public class GPS {

	private int Latitud;
	private int Longituda;

	public int getLatitud() {
		return Latitud;
	}

	public void setLatitud(int latitud) {
		Latitud = latitud;
	}

	public int getLongituda() {
		return Longituda;
	}

	public void setLongituda(int longituda) {
		Longituda = longituda;
	}
}
