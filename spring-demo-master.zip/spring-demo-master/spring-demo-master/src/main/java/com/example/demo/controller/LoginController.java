package com.example.demo.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.example.demo.model.UserRepositoryDetailsService;



@Controller
public class LoginController {
	
	@Autowired
	UserRepositoryDetailsService service;
	
	/*@GetMapping("/login")
	public String loginView() {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (!(auth instanceof AnonymousAuthenticationToken)) {
		    return "index";
		}
		return "login";
	}
	*/
	
	/*@GetMapping("/addRegister")
	public String addRegisterView(User usuario, Model model) {
	
		model.addAttribute("user", usuario);
		return "addRegister";
	}
	
	@PostMapping("/login")
	public String save(@Valid User user, BindingResult result, Model model) {
		
		try {
			service.add(user);
			model.addAttribute("create", true);
		} catch (Exception er) {
			model.addAttribute("create", false);
		}
		return  loginView();
	}
	*/
}
