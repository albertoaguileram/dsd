package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Peticion;
import com.example.demo.model.PeticionService;

@RestController
public class PeticionRestController {
	
	@Autowired
	PeticionService peticionService;
	
	/*---Add new peticion---*/
	@PostMapping("/peticion")
	public ResponseEntity<?> save(@RequestBody Peticion peticion) {
		peticionService.add(peticion);
		return ResponseEntity.ok().body("New peticion has been saved");
	}
	/*---Get a libro by id---*/
	@GetMapping("/peticion/{id}")
	public ResponseEntity<Peticion> get(@PathVariable("id") long id) {
		Peticion peticion= peticionService.getByCodPeticion(id);
		return ResponseEntity.ok().body(peticion);
	}
	/*---get all peticiones---*/
	@GetMapping("/peticion")
	public ResponseEntity<List<Peticion>> list() {
		List<Peticion> peticiones = peticionService.getAll();
		return ResponseEntity.ok().body(peticiones);
	}
	/*---Update a peticion by id---*/
	@PutMapping("/peticion/{id}")
	public ResponseEntity<?> update(@PathVariable("id") long id, @RequestBody Peticion peticion) {
		peticionService.update(peticion);
		return ResponseEntity.ok().body("peticion has been updated successfully.");
	}
	/*---Delete a libro by id---*/
	@DeleteMapping("/peticion/{id}")
	public ResponseEntity<?> delete(@PathVariable("id") long id) {
		peticionService.delete(id);
		return ResponseEntity.ok().body("peticion has been deleted successfully.");
	}
	
}
