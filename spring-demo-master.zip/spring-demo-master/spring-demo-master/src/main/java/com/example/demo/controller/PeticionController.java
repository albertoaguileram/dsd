package com.example.demo.controller;



import javax.validation.Valid;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Peticion;
import com.example.demo.model.PeticionService;

//Controlador de los objetos Peticion

@Controller

class PeticionController {
	@Autowired
	PeticionService peticionService;

	/*---Devuelve el template HTML de peticiones---*/
	// petición recibida por get
	@GetMapping("/peticiones")
	public String listPeticionView(Model model) {
		model.addAttribute("peticiones", peticionService.getAll());
		
		// devuelvo el template peticiones
		return "peticiones";
	}

	/*---Devuelve el formulario para crear una peticion---*/
	@GetMapping("/peticiones/add")
	public String addPeticionView(Peticion peticion, Model model) {
		model.addAttribute("peticiones", peticionService.getAll());
		model.addAttribute("peticion", peticion);
		return "addPeticion";
	}

	/*---Devuelve el formulario para editar una peticion---*/
	@GetMapping("/peticiones/edit/{codPeticion}")
	public String editPeticionView(@PathVariable("codPeticion") long codPeticion, Model model) {
		model.addAttribute("codPeticion", codPeticion);
		model.addAttribute("peticion", peticionService.getByCodPeticion(codPeticion));
		return "updatePeticion";
	}

	/*---Anade una nueva peticion al sistema y vuelve a la pantalla de consulta de peticiones---*/
	// petición recibida por post
	@PostMapping("/peticiones")
	public String save(@Valid Peticion peticion, BindingResult result, Model model) {
		
		try {
			peticionService.add(peticion);
			model.addAttribute("create", true);
		} catch (Exception er) {
			model.addAttribute("create", false);
		}
		return listPeticionView(model);
	}

	/*---Actualiza una nueva peticion del sistema---*/
	@PostMapping("/peticiones/update")
	public String update(@Valid Peticion peticion, Model model) {
		try {
			peticionService.update(peticion);
			model.addAttribute("udpate", true);
		} catch (Exception er) {
			model.addAttribute("update", false);
		}
		return listPeticionView(model);
	}

	/*---Elimina una peticion a partir de su codPeticion y vuelve a la pantalla de consulta de peticiones---*/
	// petición recibida por delete
	@DeleteMapping("/peticiones/{codPeticion}")
	public String delete(@PathVariable("codPeticion") long codPeticion, Model model) {
		try {
			peticionService.delete(codPeticion);

			model.addAttribute("delete", true);
		} catch (Exception er) {
			model.addAttribute("delete", false);
		}
		return listPeticionView(model);
	}

}
