package com.example.demo.model;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Registro {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private String firstName;

	private String lastName;

	private String email;

	private String password;

	public Registro() {
	}

	public String MD5(String md5) {
		try {
			java.security.MessageDigest md=java.security.MessageDigest.getInstance("MD5");
			byte[] array=md.digest(md5.getBytes());
			StringBuffer sb=new StringBuffer();
			for(int i=0;i<array.length;i++) {
				sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
			}
			return sb.toString();
		}catch(java.security.NoSuchAlgorithmException e) {
			return null;
		}
		
	}

	public Registro(Registro reg) {
		this.id = reg.id;
		this.firstName = reg.firstName;
		this.lastName = reg.lastName;
		this.email = reg.email;
		this.password = reg.password;
		
		
	}

	public Long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
