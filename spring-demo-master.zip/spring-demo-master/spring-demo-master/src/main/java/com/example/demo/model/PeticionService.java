package com.example.demo.model;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PeticionService {
	/*---Interfaz para la gestion de datos de peticiones---*/
	@Autowired
	PeticionRepository repository;

	/*---Devuelve la lista de peticiones---*/
	public List<Peticion> getAll() {
		return repository.findAll();
	}

	public void update(Peticion peticion) {
		
		Peticion p = repository.getOne(peticion.getCodPeticion());
		p.setTitulo(peticion.getTitulo());
		p.setDescripcion(peticion.getDescripcion());
		p.setPrioridad(peticion.getPrioridad());
		p.setDuracion(peticion.getDuracion());
		repository.saveAndFlush(p);
	}

	public Peticion getByCodPeticion(long codPeticion) {
		return repository.getOne(codPeticion);
	}

	public Peticion getByTitulo(String titulo) {
		return repository.findByTitulo(titulo);
	}

	public void add(Peticion peticion) {
		repository.saveAndFlush(peticion);
	}

	public void delete(long codPeticion) {
		repository.deleteById(codPeticion);
	}
}
