package com.example.demo.controller;


import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.demo.model.User;
import com.example.demo.model.UserRepositoryDetailsService;



@Controller
public class LoginController {
	
	@Autowired
	UserRepositoryDetailsService service;
	
	@GetMapping("/login")
	public String loginView() {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (!(auth instanceof AnonymousAuthenticationToken)) {
		    return "index";
		}
		return "login";
	}
	
	@GetMapping("/addRegister")
	public String addRegisterView(User usuario, Model model) {
	
		model.addAttribute("user", usuario);
		return "addRegister";
	}
	
	@PostMapping("/login")
	public String save(@Valid User user, BindingResult result, Model model) {
		
		try {
			service.add(user);
			model.addAttribute("create", true);
		} catch (Exception er) {
			model.addAttribute("create", false);
		}
		return  loginView();
	}
	
}
