package com.example.demo;

import org.springframework.boot.CommandLineRunner;







import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.model.Mensaje;
import com.example.demo.model.MensajeService;
import com.example.demo.model.PeticionService;


@SpringBootApplication
public class DemoApplication {

	// JPA
	// https://www.objectdb.com/java/jpa/entity/id

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	public CommandLineRunner demo(MensajeService mensajeService, PeticionService peticionService) {
		return (args) -> {
			// crear datos al arrancar la aplicación
			// se usa para meter datos de prueba
			Mensaje m1=new Mensaje("hola que tal");
			mensajeService.add(m1);
		
			
		
        
			
		
			
			
			
		};
	}

}
