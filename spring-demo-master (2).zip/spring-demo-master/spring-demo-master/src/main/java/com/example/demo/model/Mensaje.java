package com.example.demo.model;



import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Mensaje {
	@Id
	private String mensajevar;

	public Mensaje() {
		
	}

	public Mensaje(String mensajevar) {
		
		this.mensajevar = mensajevar;

		
	
	}
	

	

	public String getMensajevar() {
		return mensajevar;
	}
	

	public void setMensajevar(String mensajevar) {
		this.mensajevar = mensajevar;
	}

		@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final Mensaje other = (Mensaje) obj;
		if (mensajevar != other.getMensajevar()) {
			return false;

		}

		return true;
	}
		
		@Override
		public String toString() {
			return "Mensaje[Mensaje=" + mensajevar+ "]";
		}

	

}
