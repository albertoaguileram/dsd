package com.example.demo.model;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


// hacer que el sistema de autenticación de spring coja los datos de usuario de la base de datos
@Service
public class UserRepositoryDetailsService implements UserDetailsService {
	private final UserRepository userRepository;

	@Autowired
	public UserRepositoryDetailsService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	
	public void update(User usuario) {

		User usuario1=userRepository.getOne(usuario.getId());
		
	    usuario1.setEmail(usuario.getEmail());
	    usuario1.setFirstName(usuario.getFirstName());
	    usuario1.setLastName(usuario.getLastName());
	    usuario1.setPassword(usuario.getPassword());
	    userRepository.saveAndFlush(usuario1);
	
	}

	public List<User> getAll(){
		return userRepository.findAll();
	}
	public void add(User usuario) {
		userRepository.saveAndFlush(usuario);
	}
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByEmail(username);
		if (user == null) {
			throw new UsernameNotFoundException("Could not find user " + username);
		}
		return new CustomUserDetails(user);
	}

	private final static class CustomUserDetails extends User implements UserDetails {

		/**
		 * 
		 */
		private static final long serialVersionUID = -5708084648279451366L;

		private CustomUserDetails(User user) {
			super(user);
		}


		@Override
		public Collection<? extends GrantedAuthority> getAuthorities() {
			return AuthorityUtils.createAuthorityList("ROLE_USER");
		}

		@Override
		public String getUsername() {
			return getEmail();
		}

	
		@Override
		public boolean isAccountNonExpired() {
			return true;
		}

		@Override
		public boolean isAccountNonLocked() {
			return true;
		}

		@Override
		public boolean isCredentialsNonExpired() {
			return true;
		}

		@Override
		public boolean isEnabled() {
			return true;
		}
	}
}

