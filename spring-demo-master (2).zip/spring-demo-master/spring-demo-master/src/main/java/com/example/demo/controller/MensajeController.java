package com.example.demo.controller;

import javax.validation.Valid;


import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.MensajeService;
import com.example.demo.model.Mensaje;

@Controller
public class MensajeController {

	
	//Controlador de los objetos Mensajes

	

	
		@Autowired
		MensajeService mensajeService;

		/*---Devuelve el template HTML de mensajes---*/
		@GetMapping("/mensajes")
		public String listMensajeView(Model model) {
			// datos que seran accesibles desde la plantilla (frontend)
			model.addAttribute("mensajes", mensajeService.getAll());
			// devuelvo el template peticiones
			return "mensajes";
		}

		/*---Devuelve el formulario para crear un mensaje---*/
		@GetMapping("/mensajes/add")
		public String addMensajeView(Mensaje mensaje, Model model) {
			model.addAttribute("mensajes", mensajeService.getAll());
			model.addAttribute("mensaje",mensaje);
			return "addMensaje";
		}

	
		/*---Anade un nuevo mensaje al sistema y vuelve a la pantalla de consulta de mensajes---*/

		@PostMapping("/mensajes")
		public String save(@Valid Mensaje mensaje, BindingResult result, Model model) {
			
			try {
				mensajeService.add(mensaje);
				model.addAttribute("create", true);
			} catch (Exception er) {
				model.addAttribute("create", false);
			}
			return listMensajeView(model);
		}
		
		@DeleteMapping("/mensajes/{mensajevar}")
		public String delete(@PathVariable("mensajevar") String mensajevar, Model model) {
			try {
				mensajeService.delete(mensajevar);
				model.addAttribute("delete", true);
			} catch (Exception er) {
				model.addAttribute("delete", false);
			}
			return listMensajeView(model);
		}
	}



