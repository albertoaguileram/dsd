package com.example.demo;

import org.springframework.boot.CommandLineRunner;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.model.Mensaje;
import com.example.demo.model.MensajeService;
import com.example.demo.model.Peticion;
import com.example.demo.model.PeticionService;


@SpringBootApplication
public class DemoApplication {

	// JPA
	// https://www.objectdb.com/java/jpa/entity/id

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	public CommandLineRunner demo(MensajeService mensajeService, PeticionService peticionService) {
		return (args) -> {
			// crear datos al arrancar la aplicación
			// se usa para meter datos de prueba
			Mensaje m1=new Mensaje("me interesa esa petición");
			mensajeService.add(m1);
			
			Peticion p1=new Peticion(1234,"Mudanza","Necesito Mudanza para una casa",3,45);
			Peticion p2=new Peticion(5555,"Soporte técnico","Necesito una ayuda con mi ordenador",5,32);
			peticionService.add(p1);
            peticionService.add(p2);			
					
		};
	}

}
