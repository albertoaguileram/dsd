package com.example.demo.model;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PeticionRepository extends JpaRepository<Peticion, Long> {

	// Además de los metodos de consulta básico indico que quiero un método que
	// busque por titulo de la peticion
	// A través del nombre del metodo, spring sabe que tiene que hacer una consulta
	// y devolver la peticion con el titulo especificado
	// findBy"Titulo" titulo debe existir en la clase peticion
	Peticion findByTitulo(String peticionTitulo);

	Peticion findByPrioridad(Integer prioridad);

}
