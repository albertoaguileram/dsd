package com.example.demo.controller;

import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import com.example.demo.model.User;
import com.example.demo.model.UserRepositoryDetailsService;

@Controller
public class LoginController {

	@Autowired
	UserRepositoryDetailsService service;

	@GetMapping("/login")
	public String loginView() {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (!(auth instanceof AnonymousAuthenticationToken)) {
			return "index";
		}
		return "login";
	}

	@GetMapping("/register")
	public String listView(Model model) {
		model.addAttribute("register", service.getAll());
		return "login";
	}

	@GetMapping("/register/add")
	public String addRegisterView(User usr, Model model) {

		model.addAttribute("usuario", usr);
		return "addUser";
	}

	@PostMapping("/register")
	public String save(@Valid User usr, BindingResult result, Model model) {

	

		usr.setPassword("$2a$10$CfUsDmOU/a6/mXdOd50fJeMNFhEnuvsuQkYRKvtbLPNSEG5ym1aRy"); 
//contraseña paco123 encriptada a bCrypt (únicamente se puede poner paco123 para poder registrarse para esta versión)
		try {
			service.add(usr);
			model.addAttribute("create", true);
		} catch (Exception er) {
			model.addAttribute("create", false);
		}
		return listView(model);
	}
	
	
}
