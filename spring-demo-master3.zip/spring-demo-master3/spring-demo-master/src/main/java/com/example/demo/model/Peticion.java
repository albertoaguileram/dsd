package com.example.demo.model;

import javax.persistence.*;
@Entity
public class Peticion {

	@Id
	private long codPeticion;

	private String titulo;
	private String descripcion;
	private Integer prioridad;
	private Integer duracion;
	


	public Peticion() {

	}
	public Peticion(long codPeticion,String titulo,String descripcion,Integer prioridad,Integer duracion) {

		this.codPeticion=codPeticion;
		
		this.titulo=titulo;
		this.descripcion=descripcion;
		this.prioridad=prioridad;
		this.duracion=duracion;
		
	}

	

	public Integer getDuracion() {
		return duracion;
	}

	public void setDuracion(Integer duracion) {
		this.duracion = duracion;
	}

	public void setCodPeticion(long codPeticion) {
		this.codPeticion = codPeticion;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public long getCodPeticion() {
		return codPeticion;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public Integer getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(Integer prioridad) {
		this.prioridad = prioridad;
	}

	public int hashCode() {
		try {
			return (int) codPeticion;
		} catch (Exception er) {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		
		if (obj == null)
			return false;
		
		final Peticion other = (Peticion) obj;
		if (codPeticion != other.getCodPeticion() || titulo != other.getTitulo()
				|| descripcion != other.getDescripcion()) {
			return false;

		}

		return true;
	}

	@Override
	public String toString() {
		return "Peticion [codPeticion=" + codPeticion + ", titulo=" + titulo + ", descripcion=" + descripcion + "]";
	}
}
