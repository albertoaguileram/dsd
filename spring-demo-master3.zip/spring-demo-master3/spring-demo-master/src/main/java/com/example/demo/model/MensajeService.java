package com.example.demo.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class MensajeService {
	/*---Interfaz para la gestion de datos de peticiones---*/
	@Autowired
	MensajeRepository repository;
	
	public List<Mensaje> getAll() {
		return repository.findAll();
	}
	
	public void add(Mensaje mensaje) {
		repository.saveAndFlush(mensaje);
	}
	
	public void delete(String mensaje) {
		repository.deleteById(mensaje);;
	}
	public Mensaje getByMensaje(String mensajevar) {
		return repository.getOne(mensajevar);
	}
}
