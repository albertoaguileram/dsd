package com.example.demo.model;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Postal {
	@Id
	private int CP;
	private String Calle;
	private int Numero;

	public int getCP() {
		return CP;
	}

	public String getCalle() {
		return Calle;
	}

	public int getNumero() {
		return Numero;
	}

	public void setCP(int cP) {
		CP = cP;
	}

	public void setCalle(String calle) {
		Calle = calle;
	}

	public void setNumero(int numero) {
		Numero = numero;
	}

}
