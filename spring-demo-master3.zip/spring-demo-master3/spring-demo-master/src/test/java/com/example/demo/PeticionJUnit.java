package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import com.example.demo.model.Peticion;

public class PeticionJUnit {

	public static Peticion p;
	public static long codPeticion = 555;
	public static String titulo = "Cuidar niños";

	public static String descripcion = "Necesito una persona que me cuide los niños durante cierto tiempo";
	public static Integer prioridad = 3;
	public static Integer duracion = 30;

	@BeforeClass
	public static void create_peticion() {
		p = new Peticion();
		p.setCodPeticion(codPeticion);
		p.setTitulo(titulo);
		p.setDescripcion(descripcion);
		p.setPrioridad(prioridad);
		p.setDuracion(duracion);

	}

	@Test
	public void peticion() {
		assertEquals("Comprobando codPeticion", codPeticion, p.getCodPeticion());
		assertEquals("Comprobando titulo", titulo, p.getTitulo());
		assertEquals("Comprobando descripcion", descripcion, p.getDescripcion());
		assertEquals("Comprobando prioridad", prioridad, p.getPrioridad());
		assertEquals("Comprobando duracion", duracion, p.getDuracion());

	}
}
