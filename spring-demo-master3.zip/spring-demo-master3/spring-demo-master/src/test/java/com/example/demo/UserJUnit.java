package com.example.demo;

import static org.junit.Assert.assertEquals;




import org.junit.BeforeClass;
import org.junit.Test;
import com.example.demo.model.User;

public class UserJUnit {

	public static User user;
	/*@GeneratedValue(strategy = GenerationType.AUTO)
	public static long id;
	*/
	public static String firstName="Pepe";

	public static String lastName="Moreno";

	public static String email="pepe123@mail.com";

	public static String password="policia1";
	
	@BeforeClass
	public static void create_user() {
		user=new User();
		//r.setId(id);
		user.setEmail(email);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setPassword(password);
		
	}
	
	@Test
	public void user() {
		//assertEquals("Comprobando id",id,r.getId()); 
        assertEquals("Comprobando email",email,user.getEmail());
        assertEquals("Comprobando nombre",firstName,user.getFirstName());
        assertEquals("Comprobando primer apellido",lastName,user.getLastName());
        assertEquals("Comprobando contraseña",password,user.getPassword());
        
		
	}
	
}
