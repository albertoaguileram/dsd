package com.example.demo;

import static org.junit.Assert.assertEquals;


import org.junit.BeforeClass;
import org.junit.Test;

import com.example.demo.model.Mensaje;

public class MensajeJUnit {

	public static Mensaje m;
	public static String mensajevar = "Me interesa esa peticion";

	@BeforeClass
	public static void create_mensaje() {
     m=new Mensaje();
     m.setMensajevar(mensajevar);
     
	}
	@Test
	public void mensaje() {
		assertEquals("Comprobando mensaje",mensajevar,m.getMensajevar());
	}
}
