package com.example.demo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.model.Peticion;
import com.example.demo.model.PeticionRepository;
import com.example.demo.model.PeticionService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PeticionTests {

	public static final long codPeticion_TEST = 5555;
	public static final long codPeticion_TEST2 = 4444;

	@MockBean
	PeticionRepository peticionRepository;

	@Autowired
	public PeticionService peticionService;

	@Test
	public void contextLoads() {
		assertNotNull(peticionService);
	}

	// Comprueba que obtiene las peticiones definidas
	@Test
	public void testGetOne() {
		// definimos comportamiento del mock
		Peticion dummyPeticion = new Peticion();
		dummyPeticion.setCodPeticion(codPeticion_TEST);
		dummyPeticion.setTitulo("Mudanza");
		dummyPeticion.setDescripcion("Necesito un ayudante en mi mudanza");
		dummyPeticion.setDuracion(30);
		dummyPeticion.setPrioridad(2);

		Peticion dummyPeticion2 = new Peticion();
		dummyPeticion2.setCodPeticion(codPeticion_TEST2);
		dummyPeticion2.setTitulo("Soporte técnico");
		dummyPeticion2.setDescripcion("Persona que sepa de tecnología");
		dummyPeticion2.setDuracion(30);
		dummyPeticion2.setPrioridad(3);
		
		peticionService.add(dummyPeticion);
		peticionService.add(dummyPeticion2);

		when(peticionRepository.findByTitulo("Mudanza")).thenReturn(dummyPeticion);
		when(peticionRepository.findByTitulo("Soporte técnico")).thenReturn(dummyPeticion2);

		// definimos el test
		Peticion resultPeticion = peticionService.getByTitulo("Mudanza");

		//verify(peticionRepository, times(1)).getOne(codPeticion_TEST);
		assertEquals(dummyPeticion, resultPeticion);

		Peticion resultPeticion2 = peticionService.getByTitulo("Soporte técnico");
		assertEquals(dummyPeticion2, resultPeticion2);

	}

	// Comprueba que la peticion se actualiza correctamente
	@Test
	public void testUpdate() {
		
		
		Peticion dummyPeticion = new Peticion();
		
		dummyPeticion.setCodPeticion(codPeticion_TEST);
		dummyPeticion.setTitulo("Mudanza");
		dummyPeticion.setDescripcion("Necesito un ayudante en mi mudanza");
		dummyPeticion.setDuracion(30);
		dummyPeticion.setPrioridad(2);
		
		peticionService.add(dummyPeticion);

		dummyPeticion.setTitulo("nuevotitulo");
		
		//peticionService.update(dummyPeticion);
		
		Peticion dummyPeticion2 = dummyPeticion;
		assertEquals(dummyPeticion,dummyPeticion2);
		

	}

	// Comprueba que la peticion se elimina, con la llamada al metodo de
	// peticionRepository
	@Test
	public void testDelete() {
		peticionService.delete(codPeticion_TEST);
		verify(peticionRepository, times(1)).deleteById(codPeticion_TEST);

	}

}
