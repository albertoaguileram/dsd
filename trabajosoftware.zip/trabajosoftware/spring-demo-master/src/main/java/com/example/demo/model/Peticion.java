package com.example.demo.model;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Peticion {

	@Id
	private long codPeticion=0;

	private String titulo;
	private String descripcion;

	public Peticion() {
		
	}
	public Peticion(String titulo, String descripcion) {
	   this.codPeticion++;
		this.titulo = titulo;
		this.descripcion = descripcion;
	
	}
	

	public void setCodPeticion(long codPeticion) {
		this.codPeticion = codPeticion;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public long getCodPeticion() {
		return codPeticion;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public int hashCode() {
		try {
			return (int) codPeticion;
		} catch (Exception er) {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final Peticion other = (Peticion) obj;
		if (codPeticion != other.getCodPeticion() || titulo != other.getTitulo()
				|| descripcion != other.getDescripcion()) {
			return false;

		}

		return true;
	}

	@Override
	public String toString() {
		return "Peticion [codPeticion=" + codPeticion + ", titulo=" + titulo + "y descripcion=" + descripcion + "]";
	}
}
